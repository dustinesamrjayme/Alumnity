export const environment = {
    supabaseUrl:  'https://czbgcseyleqpxylypvpd.supabase.co',
    supabaseAnonKey: 'sb_publishable_qqHq9E_ey7GTGjml1UWQDQ_xiCPFHUf',
    production: false,
};