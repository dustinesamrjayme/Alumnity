// src/app/core/models.ts
// TypeScript models matching schema_v2.sql

// ---------- Enums (string unions mirror the Postgres enums) ----------
export type UserRole = 'alumni' | 'admin' | 'volunteer';
export type EventStatus = 'listed' | 'closed';
export type AttendeeStatus = 'not_checked_in' | 'checked_in' | 'cancelled';
export type PaymentStatus = 'unpaid' | 'paid' | 'free';
export type ScanResult = 'accepted' | 'duplicate' | 'rejected';
export type Department = 'CEIT' | 'CABA' | 'COE' | 'CAS';
export type Program = 'BSEE' | 'BSIT' | 'BSCE' ;

// ---------- Users ----------
// password_hash is intentionally absent: the API never returns it.
export interface AppUser {
  id: string; // uuid, same as auth user id
  first_name: string;
  last_name: string;
  email: string;
  username: string;
  phone: string;
  department: Department;
  program: Program;
  batch: string;
  role: UserRole;
  created_at: string; // ISO timestamp
}

/** Explicit column list. select('*') on users fails because password_hash is not granted. */
export const USER_COLUMNS =
  'id, first_name, last_name, email, username, phone, department, program, batch, role, created_at';

export interface SignUpInput {
  email: string;
  password: string;
  first_name: string;
  last_name: string;
  username: string;
  phone: string;
  department: Department;
  program: Program;
  batch: string;
}

export interface SignInInput {
  email: string;
  password: string;
}

/** Fields a user may edit on their own profile (matches the column grant). */
export type ProfileUpdate = Partial<
  Pick<AppUser, 'username' | 'first_name' | 'last_name' | 'phone' | 'department' | 'program' | 'batch'>
>;

// ---------- Events ----------
export interface EventItem {
  id: number;
  name: string;
  venue: string;
  description: string;
  event_date: string;
  price: number | null;
  capacity: number | null; // null = unlimited
  banner_url: string | null;
  status: EventStatus;
  created_by: string | null;
  closed_at: string | null;
}

export type NewEvent = Pick<
  EventItem,
  'name' | 'venue' | 'description' | 'event_date' | 'price' | 'capacity' | 'banner_url'
>;

export type EventUpdate = Partial<NewEvent>;

// ---------- Registrations ----------
export interface Registration {
  id: number;
  event_id: number;
  user_id: string;
  attendee_status: AttendeeStatus;
  payment_status: PaymentStatus;
  checked_in_at: string | null;
  payment_collected_by: string | null;
  payment_collected_at: string | null;
  created_at: string;
  qr_token: string; // uuid, goes in the QR code
}

/** Registration joined with its event, for the "my tickets" screen. */
export interface MyTicket extends Registration {
  event: Pick<EventItem, 'id' | 'name' | 'venue' | 'event_date' | 'price' | 'status' | 'banner_url'>;
}

// ---------- Check-in (staff side) ----------
/** One row of get_attendee_list(): names and ticket state only. */
export interface Attendee {
  registration_id: number;
  qr_token: string;
  first_name: string;
  last_name: string;
  attendee_status: AttendeeStatus;
  payment_status: PaymentStatus;
  checked_in_at: string | null;
}

/** Queue item stored in the device's SQLite and sent to sync_check_ins(). */
export interface PendingCheckIn {
  client_id: string; // crypto.randomUUID() on the device
  registration_id: number;
  device_time: string; // ISO timestamp from the device clock
  device_id?: string;
  is_offline: boolean;
}

/** Local queue row = PendingCheckIn + local bookkeeping. */
export interface LocalCheckInRow extends PendingCheckIn {
  synced: boolean;
  result?: ScanResult;
}

export interface SyncResult {
  client_id: string;
  result: ScanResult;
}

export interface CheckInLogEntry {
  id: number;
  client_id: string;
  registration_id: number;
  event_id: number;
  scanned_by: string;
  device_id: string | null;
  result: ScanResult;
  is_offline: boolean;
  device_time: string;
  synced_at: string;
}

// ---------- Admin ----------
export interface EventDashboardStats {
  event_id: number;
  name: string;
  capacity: number | null;
  registered: number;
  checked_in: number;
  cancelled: number;
  paid: number;
  unpaid: number;
  revenue: number;
}

export interface AuditLogEntry {
  id: number;
  actor_id: string | null;
  action:
    | 'payment_confirmed'
    | 'registration_cancelled'
    | 'event_closed'
    | 'event_listed'
    | 'event_updated'
    | string;
  table_name: string;
  record_id: number;
  details: Record<string, unknown> | null;
  created_at: string;
}

// ---------- Errors ----------
/** Postgres error codes raised by the RPC functions. */
export const DB_ERROR = {
  ALREADY_REGISTERED: '23505', // unique_violation
  NOT_FOUND: 'P0002',
  RULE_VIOLATION: 'P0001', // event closed / full / already checked in ...
  FORBIDDEN: '42501',
  NOT_AUTHENTICATED: '28000',
} as const;
